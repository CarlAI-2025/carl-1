# Third-party notices

This product-owned preview recognizer is not an SDK distribution or a model
license acceptance flow.

* **Foundry Local Java SDK 0.1.0-preview.1-1c7c2a6bc7da**: MIT. The separate,
  unmodified SDK JAR retains its embedded license and notices. Approved source:
  https://github.com/ghc-jetbrains/foundry-local-java-sdk-preview/tree/java-sdk-v0.1.0-preview.1-1c7c2a6bc7da
* **Java Native Access 5.17.0**: Apache License 2.0 option. The separate,
  unmodified JNA JAR retains its licenses and third-party notices, including
  native libffi notices. Source:
  https://github.com/java-native-access/jna/tree/5.17.0
* **Gson 2.11.0**: Apache License 2.0. The complete, unmodified Gson JAR is
  resolved from Maven Central and copied into the installation.
  `GSON_LICENSE.txt` accompanies the installed dependency.
  Source: https://github.com/google/gson/tree/gson-parent-2.11.0
* **JUnit 4.13.2**: Eclipse Public License 1.0. Test-only; not installed with
  the recognizer. Source: https://github.com/junit-team/junit4/tree/r4.13.2

No model weights or native runtime bundle are copied into the recognizer or its
installation. Runtime preparation must separately retain the licenses and
notices of Microsoft.AI.Foundry.Local.Runtime 2.0.1, Microsoft.ML.OnnxRuntime
1.28.0, and Microsoft.ML.OnnxRuntimeGenAI.Foundry 0.15.2.

The copied model lock records provenance, not redistribution permission.
The exact prepared model's `LICENSE` and `NOTICES` are verified with its other
files. The observed Microsoft MIT license, NVIDIA Open Model License notice,
Silero VAD MIT notice, and upstream model card's OpenMDW-1.1 description remain
distinct. This recognizer neither resolves those differences nor downloads or
accepts model terms.
